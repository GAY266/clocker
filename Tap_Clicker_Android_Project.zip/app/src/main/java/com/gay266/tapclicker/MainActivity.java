package com.gay266.tapclicker;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import java.util.Random;

public class MainActivity extends Activity {
    long coins = 0;
    int clicks = 0, skinIndex = 0, abilityIndex = 0;
    int multiplier = 1;
    long abilityUntil = 0;
    final Random random = new Random();
    TextView coinText, statsText, skinText, abilityText;
    final String[] rarities = {"Обычный", "Необычный", "Эпический", "Легендарный", "Миллионер"};
    final String[] skins = {
        "Pixel", "Blue Dot", "Mint", "Sunset", "Lime", "Ruby", "Ocean", "Cloud", "Copper", "Night",
        "Neon", "Frost", "Circuit", "Comet", "Jade", "Turbo", "Glitch", "Aurora", "Volt", "Laser",
        "Phantom", "Galaxy", "Dragon", "Inferno", "Void", "Prism", "Titan", "Storm", "Nova", "Eclipse",
        "Crown", "Royal", "Diamond", "Emperor", "Phoenix", "Infinity", "Cosmic", "Overlord", "Mythic", "Legend",
        "Million", "Gold Rush", "Money Rain", "Rich Cat", "Big Boss", "Gold King", "Vault", "Tycoon", "Billionaire", "Money God"
    };
    int[] owned = new int[50];
    int[] rarityByIndex = new int[50];

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        for (int i=0;i<50;i++) rarityByIndex[i] = i/10;
        owned[0] = 1;
        buildUi();
        refresh();
    }

    int dp(int n) { return (int)(n * getResources().getDisplayMetrics().density + 0.5f); }
    TextView text(String s, int size) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size);
        t.setTextColor(Color.rgb(30,35,50)); t.setGravity(Gravity.CENTER);
        t.setPadding(dp(8),dp(8),dp(8),dp(8)); return t;
    }
    Button button(String label, Runnable action) {
        Button b = new Button(this); b.setText(label);
        b.setOnClickListener(v -> action.run()); return b;
    }
    void buildUi() {
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(242,246,252));
        TextView title = text("TAP CLICKER: CASE RUSH", 22); title.setTypeface(null, Typeface.BOLD);
        title.setTextColor(Color.rgb(28,95,210)); root.addView(title);
        ScrollView scroll = new ScrollView(this);
        LinearLayout content = new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL);
        coinText = text("Монеты: 0", 24); coinText.setTypeface(null,Typeface.BOLD); content.addView(coinText);
        statsText = text("Кликов: 0 · Множитель: x1", 16); content.addView(statsText);
        Button tap = button("⚡ ТАП! +монеты", () -> {
            clicks++;
            int m = (System.currentTimeMillis() < abilityUntil) ? 2 : 1;
            coins += multiplier * m;
            refresh();
        });
        tap.setTextSize(22); content.addView(tap);
        content.addView(text("📦 КЕЙСЫ",20));
        content.addView(button("Открыть обычный кейс — 50 монет", () -> openCase(50)));
        content.addView(button("Открыть редкий кейс — 250 монет", () -> openCase(250)));
        content.addView(button("Открыть эпический кейс — 1000 монет", () -> openCase(1000)));
        content.addView(text("🎨 СКИНЫ",20));
        skinText = text("Текущий скин: Pixel",16); content.addView(skinText);
        content.addView(button("Следующий скин (проверить)", () -> {
            int next = (skinIndex + 1) % 50;
            if (owned[next] == 0) {
                int cost = (rarityByIndex[next]+1)*150;
                if (coins < cost) { toast("Нужно " + cost + " монет"); return; }
                coins -= cost; owned[next] = 1;
            }
            skinIndex = next;
            multiplier = rarityByIndex[skinIndex] == 4 ? 3 : rarityByIndex[skinIndex] == 3 ? 2 : 1;
            refresh(); toast("Экипирован: " + skins[skinIndex]);
        }));
        content.addView(button("Риск-апгрейд скина — 100 монет", () -> {
            if (coins < 100) { toast("Не хватает монет"); return; }
            coins -= 100;
            if (random.nextInt(100) < 45) {
                int next = Math.min(49, skinIndex + 10);
                owned[next] = 1; skinIndex = next;
                multiplier = rarityByIndex[skinIndex] == 4 ? 3 : rarityByIndex[skinIndex] == 3 ? 2 : 1;
                toast("Успех! Получен " + rarities[rarityByIndex[next]] + " скин");
            } else toast("Неудача! Попробуй снова");
            refresh();
        }));
        content.addView(text("⏱️ СПОСОБНОСТИ",20));
        abilityText = text("Способность не активна",16); content.addView(abilityText);
        String[] abilityNames = {
            "Double Tap","Coin Burst","Lucky Minute","Quick Fingers","Gold Touch","Rush Mode",
            "Bonus Drop","Case Magnet","Critical Tap","Super Click","Flash","Overclock",
            "Pocket Change","Treasure Sense","Combo Boost","Lucky Star","Turbo Hands","Coin Shower",
            "Golden Hour","Power Tap","Mega Burst","Rapid Fire","Bonus Round","Shiny Chance",
            "Vault Breaker","Cash Wave","Tap Storm","Fortune","Hyper Mode","Millionaire Spirit"
        };
        for (int i=0;i<abilityNames.length;i++) {
            final int id = i;
            content.addView(button(abilityNames[i] + " — активировать", () -> {
                if (coins < 75) { toast("Нужно 75 монет"); return; }
                coins -= 75; abilityIndex = id; abilityUntil = System.currentTimeMillis()+15000;
                toast(abilityNames[id] + ": x2 клики на 15 секунд"); refresh();
            }));
        }
        content.addView(text("Сохранение пока действует в рамках текущего запуска.",13));
        scroll.addView(content); root.addView(scroll, new LinearLayout.LayoutParams(-1,0,1));
        setContentView(root);
    }
    void openCase(int cost) {
        if (coins < cost) { toast("Не хватает монет"); return; }
        coins -= cost;
        int r = random.nextInt(100);
        int rarity = cost >= 1000 ? (r < 40 ? 2 : r < 80 ? 3 : 4)
                   : cost >= 250 ? (r < 55 ? 1 : r < 85 ? 2 : r < 98 ? 3 : 4)
                   : (r < 65 ? 0 : r < 90 ? 1 : r < 98 ? 2 : r < 100 ? 3 : 4);
        int idx = rarity*10 + random.nextInt(10);
        owned[idx] = 1;
        toast("Выпал скин: " + skins[idx] + " (" + rarities[rarity] + ")");
        refresh();
    }
    void refresh() {
        if (coinText == null) return;
        coinText.setText("Монеты: " + coins);
        statsText.setText("Кликов: " + clicks + " · Множитель: x" + multiplier);
        skinText.setText("Текущий скин: " + skins[skinIndex] + " · " + rarities[rarityByIndex[skinIndex]]);
        abilityText.setText(System.currentTimeMillis() < abilityUntil ? "Активна: x2 клики!" : "Способность не активна");
    }
    void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_SHORT).show(); }
}
