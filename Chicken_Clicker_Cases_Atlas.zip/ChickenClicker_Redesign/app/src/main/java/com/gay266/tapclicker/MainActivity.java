package com.gay266.tapclicker;
import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class MainActivity extends Activity {
 @Override public void onCreate(Bundle b) { super.onCreate(b); getWindow().setStatusBarColor(0xFF9D9D9D); getWindow().setNavigationBarColor(0xFF050505); WebView w=new WebView(this); w.setBackgroundColor(0xFF9D9D9D); WebSettings s=w.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); w.setWebViewClient(new WebViewClient()); w.loadUrl("file:///android_asset/index.html"); setContentView(w); }
 @Override public void onBackPressed() { super.onBackPressed(); }
}
